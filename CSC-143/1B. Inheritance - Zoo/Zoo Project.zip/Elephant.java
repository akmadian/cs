// Ari Madian
// Ravi Gandham CSC 143 W19

public class Elephant extends Animal {

    public Elephant()
    {
        super();
    }

    public void Talk()
    {
        System.out.println("The elephant trumpets!");
    }

    public String ToString()
    {
        return "Elephant";
    }
}
