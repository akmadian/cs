// Ari Madian
// Ravi Gandham CSC 143 W19

public class Giraffe extends Animal {

    public Giraffe()
    {
        super();
    }

    public void Talk()
    {
        System.out.println("What do giraffes say?");
    }

    public String ToString()
    {
        return "Giraffe";
    }
}
